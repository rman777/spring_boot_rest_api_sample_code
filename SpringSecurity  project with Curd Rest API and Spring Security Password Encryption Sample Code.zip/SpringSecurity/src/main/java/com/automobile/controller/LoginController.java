package com.automobile.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.automobile.model.Users;
import com.automobile.service.UsersService;

@RestController
public class LoginController {

	@Autowired
	private UsersService usersService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@RequestMapping("/")
	public String index() {
		return "Welcome to Rest API";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public Users saveUser(@RequestBody Users users) {
		users.setUser_password(passwordEncoder.encode(users.getUser_password()));
		Users result =  usersService.saveRegisterData(users);	
		return result;
	}
	
	@RequestMapping(value="/getuser",method = RequestMethod.POST)
	public Optional<Users> getUserDetails(@RequestBody Users users) {
		 return usersService.findById(users.getUser_id());
	}
	
	@RequestMapping(value="/deleteuser",method=RequestMethod.POST)
	public String deleteUser(@RequestBody Users users) {
		return usersService.deleteUserById(users.getUser_id());
	}
	
	
	@RequestMapping(value="/getAllUsers")
	public List<Users> getAllUsersData(){
		return usersService.getAllUsers();
	}
	
}
