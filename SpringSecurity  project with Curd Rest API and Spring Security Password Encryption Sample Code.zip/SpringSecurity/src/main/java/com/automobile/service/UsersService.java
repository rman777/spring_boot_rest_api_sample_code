package com.automobile.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.automobile.model.Users;
import com.automobile.repository.UsersRepository;

@Service
@Transactional
public class UsersService {

	@Autowired 
	UsersRepository usersRepository;

	public Users saveRegisterData(Users users) {
		return usersRepository.save(users);
	}

	public Optional<Users> findById(Long user_id) {
		return usersRepository.findById(user_id);
	}

	public String deleteUserById(Long user_id) {
		 usersRepository.deleteById(user_id);
		 return "User Deleted Successfully";
	}

	public List<Users> getAllUsers() {
		return usersRepository.findAll();
	}

	
	

	
}
